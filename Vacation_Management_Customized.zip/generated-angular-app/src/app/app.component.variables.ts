export const variables = {
  "appNotification" : {
    "_id" : "wm-appErrorHandler-wm.NotificationVariable-1454664620943",
    "name" : "appNotification",
    "owner" : "App",
    "category" : "wm.NotificationVariable",
    "dataBinding" : [ {
      "target" : "class",
      "value" : "Error",
      "type" : "list"
    }, {
      "target" : "toasterPosition",
      "value" : "bottom right",
      "type" : "list"
    } ],
    "operation" : "toast"
  },
  "goToPage_ApplyVacation" : {
    "_id" : "wm-goToPage_ApplyVacation-wm.NavigationVariable-1584432944669",
    "name" : "goToPage_ApplyVacation",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "ApplyVacation",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_Dashboard" : {
    "_id" : "wm-goToPage_Dashboard-wm.NavigationVariable-1584432972549",
    "name" : "goToPage_Dashboard",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "Dashboard",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_EmployeeDetails" : {
    "_id" : "wm-goToPage_EmployeeDetails-wm.NavigationVariable-1584432936152",
    "name" : "goToPage_EmployeeDetails",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "EmployeeDetails",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_Employees" : {
    "_id" : "wm-goToPage_Employees-wm.NavigationVariable-1584432919241",
    "name" : "goToPage_Employees",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "Employees",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_Main" : {
    "_id" : "wm-wm.NavigationVariable1389180517517",
    "name" : "goToPage_Main",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "operation" : "gotoPage",
    "pageName" : "Main"
  },
  "goToPage_PendingApproval" : {
    "_id" : "wm-goToPage_PendingApproval-wm.NavigationVariable-1584432952883",
    "name" : "goToPage_PendingApproval",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "PendingApproval",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "loggedInUser" : {
    "_id" : "wm-loggedInUser-wm.Variable-1584536328998",
    "name" : "loggedInUser",
    "owner" : "App",
    "category" : "wm.Variable",
    "dataBinding" : [ ],
    "dataSet" : {
      "name" : "",
      "id" : "",
      "tenantId" : "",
      "isAuthenticated" : false,
      "isSecurityEnabled" : true,
      "roles" : [ ]
    },
    "type" : "string",
    "isList" : false,
    "twoWayBinding" : false,
    "saveInPhonegap" : false
  },
  "loginAction" : {
    "_id" : "wm-loginAction-wm.LoginVariable-1584536328996",
    "name" : "loginAction",
    "owner" : "App",
    "category" : "wm.LoginVariable",
    "dataBinding" : [ ],
    "dataSet" : { },
    "type" : "string",
    "saveInPhonegap" : false,
    "startUpdate" : false,
    "autoUpdate" : false,
    "inFlightBehavior" : "executeLast",
    "transformationRequired" : false,
    "useDefaultSuccessHandler" : true
  },
  "logoutAction" : {
    "_id" : "wm-logoutAction-wm.LogoutVariable-1584536328997",
    "name" : "logoutAction",
    "owner" : "App",
    "category" : "wm.LogoutVariable",
    "type" : "string",
    "saveInPhonegap" : false,
    "inFlightBehavior" : "executeLast",
    "transformationRequired" : false,
    "redirectTo" : "Login",
    "useDefaultSuccessHandler" : true
  },
  "supportedLocale" : {
    "_id" : "wm-wm.Variable1402640443182",
    "name" : "supportedLocale",
    "owner" : "App",
    "category" : "wm.Variable",
    "dataSet" : {
      "en" : "English"
    },
    "type" : "string",
    "isList" : false,
    "saveInPhonegap" : false
  },
  "svEmployeeDetails" : {
    "_id" : "wm-svEmployeeDetails-wm.ServiceVariable-1584447767479",
    "name" : "svEmployeeDetails",
    "owner" : "App",
    "category" : "wm.ServiceVariable",
    "dataBinding" : [ {
      "target" : "id",
      "value" : "bind:Variables.loggedInUser.dataSet.id",
      "type" : "integer"
    } ],
    "type" : "com.vacation_management.hrdbj.Employee",
    "service" : "HRDBJ",
    "operation" : "getEmployee",
    "operationId" : "EmployeeController_getEmployee",
    "operationType" : "get",
    "serviceType" : "DataService",
    "dataSet" : [ ],
    "isList" : false,
    "maxResults" : 20,
    "startUpdate" : true,
    "autoUpdate" : true,
    "inFlightBehavior" : "executeLast",
    "transformationRequired" : false,
    "saveInPhonegap" : false,
    "controller" : "Employee"
  }
}
;

export const getVariables = () => JSON.parse(JSON.stringify(variables));
