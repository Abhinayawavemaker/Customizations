import { ComponentFactoryResolver, NgModule } from '@angular/core';
import { CommonModule as NGCommonModule, APP_BASE_HREF } from '@angular/common';

import { FormsModule as ngFormsModule } from '@angular/forms';
import { BasicModule as WM_BasicModule } from '@wm/components/basic';
import { ProgressModule as WM_ProgressModule } from '@wm/components/basic/progress';
import { LayoutGridModule as WM_LayoutGridModule } from '@wm/components/containers/layout-grid';
import { InputModule as WM_InputModule } from '@wm/components/input';
import { MenuModule as WM_MenuModule } from '@wm/components/navigation/menu';
import { BsDropdownModule as ngxBsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ComponentType,  RuntimeBaseModule } from '@wm/runtime/base';

import { ComponentRefProviderService } from '../../../framework/services/component-ref-provider.service';



import { HeaderComponent } from './header.component';

const components = [HeaderComponent];

const requiredComponentModules = [
    ngFormsModule,
	WM_BasicModule,
	WM_ProgressModule,
	WM_LayoutGridModule,
	WM_InputModule,
	WM_MenuModule,
	ngxBsDropdownModule.forRoot()
];

const requiredPartialModules = [
    
];

@NgModule({
    declarations: components,
    imports: [
        ...requiredComponentModules,
        ...requiredPartialModules,
        NGCommonModule,
        RuntimeBaseModule
    ],
    exports: components,
    entryComponents: components
})
export class HeaderModule {
    static rootComponent = HeaderComponent;
    constructor(componentFactoryResolver: ComponentFactoryResolver) {
        const cf = componentFactoryResolver.resolveComponentFactory(HeaderComponent);
        ComponentRefProviderService.registerComponentRef('header', ComponentType.PARTIAL, HeaderComponent, cf);
    }
}
