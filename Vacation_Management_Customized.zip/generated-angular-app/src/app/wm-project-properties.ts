import { setWmProjectProperties } from '@wm/core';

const properties = {
    "copyrightMsg": "Copyright (c) 2015-2016 wavemaker-com All Rights Reserved.\n This software is the confidential and proprietary information of wavemaker-com You shall not disclose such Confidential Information and shall use it only in accordance\n with the terms of the source code license agreement you entered into with wavemaker-com",
    "dateFormat": "",
    "homePage": "Main",
    "studioProjectUpgradeVersion": "103.001",
    "timeFormat": "",
    "packagePrefix": "com.vacation_management",
    "platformType": "WEB",
    "deviceTypes": "",
    "version": "1.0",
    "type": "APPLICATION",
    "defaultLanguage": "en",
    "icon": "default.png",
    "projectShellName": "WM_DEFAULT",
    "displayName": "Vacation_Management_Customized",
    "activeTheme": "material",
    "description": ""
}

setWmProjectProperties(properties);

export default () => {};
