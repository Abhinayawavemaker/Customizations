import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './PendingApproval.component.script';
import { getVariables } from './PendingApproval.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-PendingApproval',
    templateUrl: './PendingApproval.component.html',
    styleUrls: ['./PendingApproval.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: PendingApprovalComponent
        }
    ]
})
export class PendingApprovalComponent extends BasePageComponent {

    pageName = 'PendingApproval';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
