export const variables = {
    HRDBVacationData: {
        _id: "wm-HRDBVacationData-wm.LiveVariable-1585490259725",
        name: "HRDBVacationData",
        owner: "Page",
        category: "wm.LiveVariable",
        dataBinding: [],
        operation: "read",
        dataSet: [],
        type: "Vacation",
        isList: false,
        saveInPhonegap: false,
        maxResults: 20,
        designMaxResults: 10,
        inFlightBehavior: "executeLast",
        startUpdate: true,
        autoUpdate: true,
        transformationRequired: false,
        liveSource: "HRDBJ",
        ignoreCase: true,
        matchMode: "startignorecase",
        orderBy: "id asc",
        propertiesMap: {
            columns: [
                {
                    fieldName: "employee",
                    type: "integer",
                    fullyQualifiedType: "integer",
                    columnName: "EMP_ID",
                    isPrimaryKey: false,
                    notNull: true,
                    length: 0,
                    precision: 10,
                    generator: "assigned",
                    isRelated: true,
                    relatedTableName: "EMPLOYEE",
                    relatedEntityName: "Employee",
                    relatedColumnName: "empId",
                    relatedFieldName: "employee.empId",
                    isList: false,
                    targetTable: "EMPLOYEE",
                    scale: 0,
                    columns: [
                        {
                            fieldName: "department",
                            type: "integer",
                            fullyQualifiedType: "integer",
                            columnName: "DEPT_ID",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 0,
                            precision: 10,
                            generator: "assigned",
                            isRelated: true,
                            relatedColumnName: "deptId",
                            targetTable: "DEPARTMENT",
                            scale: 0
                        },
                        {
                            fieldName: "employeeByManagerId",
                            type: "integer",
                            fullyQualifiedType: "integer",
                            columnName: "MANAGER_ID",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 0,
                            precision: 10,
                            generator: "assigned",
                            isRelated: true,
                            relatedColumnName: "managerId",
                            targetTable: "EMPLOYEE",
                            scale: 0
                        },
                        {
                            fieldName: "empId",
                            type: "integer",
                            fullyQualifiedType: "integer",
                            columnName: "EMP_ID",
                            isPrimaryKey: true,
                            notNull: true,
                            length: 0,
                            precision: 10,
                            generator: "identity",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "firstname",
                            type: "string",
                            fullyQualifiedType: "string",
                            columnName: "FIRSTNAME",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 255,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "lastname",
                            type: "string",
                            fullyQualifiedType: "string",
                            columnName: "LASTNAME",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 255,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "street",
                            type: "string",
                            fullyQualifiedType: "string",
                            columnName: "STREET",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 255,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "city",
                            type: "string",
                            fullyQualifiedType: "string",
                            columnName: "CITY",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 255,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "state",
                            type: "string",
                            fullyQualifiedType: "string",
                            columnName: "STATE",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 2,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "zip",
                            type: "string",
                            fullyQualifiedType: "string",
                            columnName: "ZIP",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 255,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "birthdate",
                            type: "date",
                            fullyQualifiedType: "date",
                            columnName: "BIRTHDATE",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 0,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "jobTitle",
                            type: "string",
                            fullyQualifiedType: "string",
                            columnName: "JOB_TITLE",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 40,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "username",
                            type: "string",
                            fullyQualifiedType: "string",
                            columnName: "USERNAME",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 255,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "password",
                            type: "string",
                            fullyQualifiedType: "string",
                            columnName: "PASSWORD",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 255,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "role",
                            type: "string",
                            fullyQualifiedType: "string",
                            columnName: "ROLE",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 255,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "tenantId",
                            type: "integer",
                            fullyQualifiedType: "integer",
                            columnName: "TENANT_ID",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 0,
                            precision: 10,
                            generator: "assigned",
                            isRelated: false,
                            defaultValue: "1",
                            scale: 0
                        },
                        {
                            fieldName: "picurl",
                            type: "blob",
                            fullyQualifiedType: "blob",
                            columnName: "PICURL",
                            isPrimaryKey: false,
                            notNull: false,
                            length: -1,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "email",
                            type: "string",
                            fullyQualifiedType: "string",
                            columnName: "EMAIL",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 255,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "phone",
                            type: "string",
                            fullyQualifiedType: "string",
                            columnName: "PHONE",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 255,
                            precision: 0,
                            generator: "assigned",
                            isRelated: false,
                            scale: 0
                        },
                        {
                            fieldName: "remainingLeaves",
                            type: "integer",
                            fullyQualifiedType: "integer",
                            columnName: "REMAINING_LEAVES",
                            isPrimaryKey: false,
                            notNull: false,
                            length: 0,
                            precision: 10,
                            generator: "assigned",
                            isRelated: false,
                            defaultValue: "10",
                            scale: 0
                        }
                    ]
                },
                {
                    fieldName: "id",
                    type: "integer",
                    fullyQualifiedType: "integer",
                    columnName: "ID",
                    isPrimaryKey: true,
                    notNull: true,
                    length: 0,
                    precision: 10,
                    generator: "identity",
                    isRelated: false,
                    scale: 0
                },
                {
                    fieldName: "startDate",
                    type: "date",
                    fullyQualifiedType: "date",
                    columnName: "START_DATE",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 0,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    scale: 0
                },
                {
                    fieldName: "endDate",
                    type: "date",
                    fullyQualifiedType: "date",
                    columnName: "END_DATE",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 0,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    scale: 0
                },
                {
                    fieldName: "tenantId",
                    type: "integer",
                    fullyQualifiedType: "integer",
                    columnName: "TENANT_ID",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 0,
                    precision: 10,
                    generator: "assigned",
                    isRelated: false,
                    defaultValue: "1",
                    scale: 0
                },
                {
                    fieldName: "status",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "STATUS",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 255,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    scale: 0
                },
                {
                    fieldName: "type",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "TYPE",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 255,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    scale: 0
                }
            ],
            entityName: "Vacation",
            fullyQualifiedName: "com.vacation_management.hrdbj.Vacation",
            tableType: "TABLE",
            primaryFields: ["id"]
        },
        tableName: "VACATION",
        tableType: "TABLE",
        properties: ["employee"],
        relatedTables: [
            {
                columnName: "employee",
                relationName: "employee",
                type: "Employee",
                watchOn: "HRDBJEmployeeData",
                package: "com.vacation_management.hrdbj.Vacation"
            }
        ],
        filterFields: {},
        filterExpressions: {
            condition: "AND",
            rules: [
                {
                    target: "status",
                    type: "string",
                    matchMode: "anywhereignorecase",
                    value: "Pending",
                    required: false,
                    secondvalue: ""
                }
            ]
        },
        package: "com.vacation_management.hrdbj.Vacation"
    },
    naApproveVacation: {
        _id: "wm-naApproveVacation-wm.NotificationVariable-1584598520037",
        name: "naApproveVacation",
        owner: "Page",
        category: "wm.NotificationVariable",
        dataBinding: [
            {
                target: "content",
                value: "inline",
                type: "string"
            },
            {
                target: "text",
                value: "Vacation Approved",
                type: "string"
            },
            {
                target: "duration",
                value: "3000",
                type: "number"
            },
            {
                target: "class",
                value: "Success",
                type: "string"
            },
            {
                target: "toasterPosition",
                value: "bottom right",
                type: "string"
            }
        ],
        operation: "toast"
    },
    svApproveVacation: {
        _id: "wm-svApproveVacation-wm.ServiceVariable-1584521652680",
        name: "svApproveVacation",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "vacationID",
                value: "bind:Widgets.VacationTable1.selecteditem.id",
                type: "string"
            },
            {
                target: "vacationStatus",
                value: "Approved",
                type: "string"
            }
        ],
        type: "com.wavemaker.commons.wrapper.IntegerWrapper",
        service: "HRDBJ",
        operation: "executeUpdateVacationStatus",
        operationId: "QueryExecutionController_executeUpdateVacationStatus",
        operationType: "put",
        serviceType: "DataService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        onSuccess:
            "Variables.HRDBVacationData.listRecords();Actions.naApproveVacation.invoke()",
        startUpdate: false,
        autoUpdate: false,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        controller: "QueryExecution"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
