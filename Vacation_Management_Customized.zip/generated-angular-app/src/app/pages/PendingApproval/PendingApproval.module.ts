import { NgModule } from '@angular/core';
import { CommonModule as NgCommonModule, APP_BASE_HREF } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { RuntimeBaseModule } from '@wm/runtime/base';
import { FormsModule as ngFormsModule } from '@angular/forms';
import { ReactiveFormsModule as ngReactiveFormsModule } from '@angular/forms';
import { BasicModule as WM_BasicModule } from '@wm/components/basic';
import { ProgressModule as WM_ProgressModule } from '@wm/components/basic/progress';
import { ListModule as WM_ListModule } from '@wm/components/data/list';
import { PaginationModule as WM_PaginationModule } from '@wm/components/data/pagination';
import { TableModule as WM_TableModule } from '@wm/components/data/table';
import { InputModule as WM_InputModule } from '@wm/components/input';
import { EpochModule as WM_EpochModule } from '@wm/components/input/epoch';
import { MenuModule as WM_MenuModule } from '@wm/components/navigation/menu';
import { PageModule as WM_PageModule } from '@wm/components/page';
import { FooterModule as WM_FooterModule } from '@wm/components/page/footer';
import { HeaderModule as WM_HeaderModule } from '@wm/components/page/header';
import { LeftPanelModule as WM_LeftPanelModule } from '@wm/components/page/left-panel';
import { BsDatepickerModule as ngx_BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { DatepickerModule as ngx_DatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule as ngxBsDropdownModule } from 'ngx-bootstrap/dropdown';
import { PaginationModule as ngxPaginationModule } from 'ngx-bootstrap/pagination';
import { TimepickerModule as ngx_TimepickerModule } from 'ngx-bootstrap/timepicker';
import { TooltipModule as ngxTooltipModule } from 'ngx-bootstrap/tooltip';

import { AppCodeGenModule } from '../../app-codegen.module';

import { HeaderModule as PartialHeaderModule} from '../../partials/header/header.module';
import { LeftnavModule as PartialLeftnavModule} from '../../partials/leftnav/leftnav.module';
import { FooterModule as PartialFooterModule} from '../../partials/footer/footer.module';

import { PendingApprovalComponent } from './PendingApproval.component';

const components = [PendingApprovalComponent];

const routes: Routes = [
    {
        path: '',
        component: PendingApprovalComponent
    }
];

const requiredComponentModules = [
    ngFormsModule,
	ngReactiveFormsModule,
	WM_BasicModule,
	WM_ProgressModule,
	WM_ListModule,
	WM_PaginationModule,
	WM_TableModule,
	WM_InputModule,
	WM_EpochModule,
	WM_MenuModule,
	WM_PageModule,
	WM_FooterModule,
	WM_HeaderModule,
	WM_LeftPanelModule,
	ngx_BsDatepickerModule,
	ngx_DatepickerModule.forRoot(),
	ngxBsDropdownModule.forRoot(),
	ngxPaginationModule.forRoot(),
	ngx_TimepickerModule.forRoot(),
	ngxTooltipModule.forRoot()
];

const requiredPartialModules = [
    PartialHeaderModule,
	PartialLeftnavModule,
	PartialFooterModule
];

@NgModule({
    declarations: components,
    imports: [
        ...requiredComponentModules,
        ...requiredPartialModules,
        RouterModule.forChild(routes),
        NgCommonModule,
        AppCodeGenModule,
        RuntimeBaseModule
    ],
    exports: components
})
export class PendingApprovalModule {

}

