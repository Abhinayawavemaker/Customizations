import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './EmployeeDetails.component.script';
import { getVariables } from './EmployeeDetails.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-EmployeeDetails',
    templateUrl: './EmployeeDetails.component.html',
    styleUrls: ['./EmployeeDetails.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: EmployeeDetailsComponent
        }
    ]
})
export class EmployeeDetailsComponent extends BasePageComponent {

    pageName = 'EmployeeDetails';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
