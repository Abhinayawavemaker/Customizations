import { NgModule } from '@angular/core';
import { CommonModule as NgCommonModule, APP_BASE_HREF } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { RuntimeBaseModule } from '@wm/runtime/base';
import { BasicModule as WM_BasicModule } from '@wm/components/basic';
import { ProgressModule as WM_ProgressModule } from '@wm/components/basic/progress';
import { PageModule as WM_PageModule } from '@wm/components/page';
import { FooterModule as WM_FooterModule } from '@wm/components/page/footer';
import { HeaderModule as WM_HeaderModule } from '@wm/components/page/header';
import { LeftPanelModule as WM_LeftPanelModule } from '@wm/components/page/left-panel';

import { AppCodeGenModule } from '../../app-codegen.module';

import { HeaderModule as PartialHeaderModule} from '../../partials/header/header.module';
import { LeftnavModule as PartialLeftnavModule} from '../../partials/leftnav/leftnav.module';
import { FooterModule as PartialFooterModule} from '../../partials/footer/footer.module';

import { EmployeeDetailsComponent } from './EmployeeDetails.component';

const components = [EmployeeDetailsComponent];

const routes: Routes = [
    {
        path: '',
        component: EmployeeDetailsComponent
    }
];

const requiredComponentModules = [
    WM_BasicModule,
	WM_ProgressModule,
	WM_PageModule,
	WM_FooterModule,
	WM_HeaderModule,
	WM_LeftPanelModule
];

const requiredPartialModules = [
    PartialHeaderModule,
	PartialLeftnavModule,
	PartialFooterModule
];

@NgModule({
    declarations: components,
    imports: [
        ...requiredComponentModules,
        ...requiredPartialModules,
        RouterModule.forChild(routes),
        NgCommonModule,
        AppCodeGenModule,
        RuntimeBaseModule
    ],
    exports: components
})
export class EmployeeDetailsModule {

}

