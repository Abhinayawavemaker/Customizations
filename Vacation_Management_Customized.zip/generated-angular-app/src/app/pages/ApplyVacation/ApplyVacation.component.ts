import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './ApplyVacation.component.script';
import { getVariables } from './ApplyVacation.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-ApplyVacation',
    templateUrl: './ApplyVacation.component.html',
    styleUrls: ['./ApplyVacation.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: ApplyVacationComponent
        }
    ]
})
export class ApplyVacationComponent extends BasePageComponent {

    pageName = 'ApplyVacation';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
