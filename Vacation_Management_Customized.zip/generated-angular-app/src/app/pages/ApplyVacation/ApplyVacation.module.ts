import { NgModule } from '@angular/core';
import { CommonModule as NgCommonModule, APP_BASE_HREF } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { RuntimeBaseModule } from '@wm/runtime/base';
import { FormsModule as ngFormsModule } from '@angular/forms';
import { ReactiveFormsModule as ngReactiveFormsModule } from '@angular/forms';
import { BasicModule as WM_BasicModule } from '@wm/components/basic';
import { ProgressModule as WM_ProgressModule } from '@wm/components/basic/progress';
import { LayoutGridModule as WM_LayoutGridModule } from '@wm/components/containers/layout-grid';
import { FormModule as WM_FormModule } from '@wm/components/data/form';
import { DialogModule as WM_DialogModule } from '@wm/components/dialogs';
import { DesignDialogModule as WM_DesignDialogModule } from '@wm/components/dialogs/design-dialog';
import { InputModule as WM_InputModule } from '@wm/components/input';
import { EpochModule as WM_EpochModule } from '@wm/components/input/epoch';
import { PageModule as WM_PageModule } from '@wm/components/page';
import { FooterModule as WM_FooterModule } from '@wm/components/page/footer';
import { HeaderModule as WM_HeaderModule } from '@wm/components/page/header';
import { LeftPanelModule as WM_LeftPanelModule } from '@wm/components/page/left-panel';
import { BsDatepickerModule as ngx_BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { DatepickerModule as ngx_DatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule as ngxBsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ModalModule as ngx_ModalModule } from 'ngx-bootstrap/modal';
import { TimepickerModule as ngx_TimepickerModule } from 'ngx-bootstrap/timepicker';

import { AppCodeGenModule } from '../../app-codegen.module';

import { HeaderModule as PartialHeaderModule} from '../../partials/header/header.module';
import { LeftnavModule as PartialLeftnavModule} from '../../partials/leftnav/leftnav.module';
import { FooterModule as PartialFooterModule} from '../../partials/footer/footer.module';

import { ApplyVacationComponent } from './ApplyVacation.component';

const components = [ApplyVacationComponent];

const routes: Routes = [
    {
        path: '',
        component: ApplyVacationComponent
    }
];

const requiredComponentModules = [
    ngFormsModule,
	ngReactiveFormsModule,
	WM_BasicModule,
	WM_ProgressModule,
	WM_LayoutGridModule,
	WM_FormModule,
	WM_DialogModule,
	WM_DesignDialogModule,
	WM_InputModule,
	WM_EpochModule,
	WM_PageModule,
	WM_FooterModule,
	WM_HeaderModule,
	WM_LeftPanelModule,
	ngx_BsDatepickerModule,
	ngx_DatepickerModule.forRoot(),
	ngxBsDropdownModule.forRoot(),
	ngx_ModalModule,
	ngx_TimepickerModule.forRoot()
];

const requiredPartialModules = [
    PartialHeaderModule,
	PartialLeftnavModule,
	PartialFooterModule
];

@NgModule({
    declarations: components,
    imports: [
        ...requiredComponentModules,
        ...requiredPartialModules,
        RouterModule.forChild(routes),
        NgCommonModule,
        AppCodeGenModule,
        RuntimeBaseModule
    ],
    exports: components
})
export class ApplyVacationModule {

}

