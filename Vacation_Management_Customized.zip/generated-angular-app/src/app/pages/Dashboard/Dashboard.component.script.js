export const initScript = (Page, App, Utils) => {
    /* perform any action on widgets within this block */
    Page.onReady = function() {
        /*
         * widgets can be accessed through 'Page.Widgets' property here
         * e.g. to get value of text widget named 'username' use following script
         * 'Page.Widgets.username.datavalue'
         */
    };

}