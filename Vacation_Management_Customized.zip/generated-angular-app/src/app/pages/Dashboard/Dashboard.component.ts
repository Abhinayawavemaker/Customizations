import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './Dashboard.component.script';
import { getVariables } from './Dashboard.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-Dashboard',
    templateUrl: './Dashboard.component.html',
    styleUrls: ['./Dashboard.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: DashboardComponent
        }
    ]
})
export class DashboardComponent extends BasePageComponent {

    pageName = 'Dashboard';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
