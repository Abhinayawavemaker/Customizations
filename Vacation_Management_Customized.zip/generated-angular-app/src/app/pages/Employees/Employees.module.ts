import { NgModule } from '@angular/core';
import { CommonModule as NgCommonModule, APP_BASE_HREF } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { RuntimeBaseModule } from '@wm/runtime/base';
import { FormsModule as ngFormsModule } from '@angular/forms';
import { BasicModule as WM_BasicModule } from '@wm/components/basic';
import { ProgressModule as WM_ProgressModule } from '@wm/components/basic/progress';
import { LayoutGridModule as WM_LayoutGridModule } from '@wm/components/containers/layout-grid';
import { CardModule as WM_CardModule } from '@wm/components/data/card';
import { ListModule as WM_ListModule } from '@wm/components/data/list';
import { PaginationModule as WM_PaginationModule } from '@wm/components/data/pagination';
import { InputModule as WM_InputModule } from '@wm/components/input';
import { MenuModule as WM_MenuModule } from '@wm/components/navigation/menu';
import { PageModule as WM_PageModule } from '@wm/components/page';
import { FooterModule as WM_FooterModule } from '@wm/components/page/footer';
import { HeaderModule as WM_HeaderModule } from '@wm/components/page/header';
import { LeftPanelModule as WM_LeftPanelModule } from '@wm/components/page/left-panel';
import { BsDropdownModule as ngxBsDropdownModule } from 'ngx-bootstrap/dropdown';
import { PaginationModule as ngxPaginationModule } from 'ngx-bootstrap/pagination';

import { AppCodeGenModule } from '../../app-codegen.module';

import { HeaderModule as PartialHeaderModule} from '../../partials/header/header.module';
import { LeftnavModule as PartialLeftnavModule} from '../../partials/leftnav/leftnav.module';
import { FooterModule as PartialFooterModule} from '../../partials/footer/footer.module';

import { EmployeesComponent } from './Employees.component';

const components = [EmployeesComponent];

const routes: Routes = [
    {
        path: '',
        component: EmployeesComponent
    }
];

const requiredComponentModules = [
    ngFormsModule,
	WM_BasicModule,
	WM_ProgressModule,
	WM_LayoutGridModule,
	WM_CardModule,
	WM_ListModule,
	WM_PaginationModule,
	WM_InputModule,
	WM_MenuModule,
	WM_PageModule,
	WM_FooterModule,
	WM_HeaderModule,
	WM_LeftPanelModule,
	ngxBsDropdownModule.forRoot(),
	ngxPaginationModule.forRoot()
];

const requiredPartialModules = [
    PartialHeaderModule,
	PartialLeftnavModule,
	PartialFooterModule
];

@NgModule({
    declarations: components,
    imports: [
        ...requiredComponentModules,
        ...requiredPartialModules,
        RouterModule.forChild(routes),
        NgCommonModule,
        AppCodeGenModule,
        RuntimeBaseModule
    ],
    exports: components
})
export class EmployeesModule {

}

