import { NgModule } from '@angular/core';
import { CommonModule as NgCommonModule, APP_BASE_HREF } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { RuntimeBaseModule } from '@wm/runtime/base';
import { PageModule as WM_PageModule } from '@wm/components/page';
import { FooterModule as WM_FooterModule } from '@wm/components/page/footer';
import { HeaderModule as WM_HeaderModule } from '@wm/components/page/header';
import { LeftPanelModule as WM_LeftPanelModule } from '@wm/components/page/left-panel';
import { RightPanelModule as WM_RightPanelModule } from '@wm/components/page/right-panel';
import { TopNavModule as WM_TopNavModule } from '@wm/components/page/top-nav';

import { AppCodeGenModule } from '../../app-codegen.module';

import { HeaderModule as PartialHeaderModule} from '../../partials/header/header.module';
import { TopnavModule as PartialTopnavModule} from '../../partials/topnav/topnav.module';
import { LeftnavModule as PartialLeftnavModule} from '../../partials/leftnav/leftnav.module';
import { RightnavModule as PartialRightnavModule} from '../../partials/rightnav/rightnav.module';
import { FooterModule as PartialFooterModule} from '../../partials/footer/footer.module';

import { MainComponent } from './Main.component';

const components = [MainComponent];

const routes: Routes = [
    {
        path: '',
        component: MainComponent
    }
];

const requiredComponentModules = [
    WM_PageModule,
	WM_FooterModule,
	WM_HeaderModule,
	WM_LeftPanelModule,
	WM_RightPanelModule,
	WM_TopNavModule
];

const requiredPartialModules = [
    PartialHeaderModule,
	PartialTopnavModule,
	PartialLeftnavModule,
	PartialRightnavModule,
	PartialFooterModule
];

@NgModule({
    declarations: components,
    imports: [
        ...requiredComponentModules,
        ...requiredPartialModules,
        RouterModule.forChild(routes),
        NgCommonModule,
        AppCodeGenModule,
        RuntimeBaseModule
    ],
    exports: components
})
export class MainModule {

}

