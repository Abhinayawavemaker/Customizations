import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './ManageEmployee.component.script';
import { getVariables } from './ManageEmployee.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-ManageEmployee',
    templateUrl: './ManageEmployee.component.html',
    styleUrls: ['./ManageEmployee.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: ManageEmployeeComponent
        }
    ]
})
export class ManageEmployeeComponent extends BasePageComponent {

    pageName = 'ManageEmployee';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
