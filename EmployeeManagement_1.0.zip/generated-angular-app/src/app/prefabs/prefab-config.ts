import { registerPrefabConfig } from '../../framework/util/page-util';

export const initPrefabConfig = () => {
    
    return true;
};