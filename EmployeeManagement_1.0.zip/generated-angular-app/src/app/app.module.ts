import { NgModule, ModuleWithProviders } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClientModule, HttpClientXsrfModule } from '@angular/common/http';

import { ModalModule } from 'ngx-bootstrap/modal';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { ToastNoAnimationModule } from 'ngx-toastr';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';


import {
    AppComponent,
    AppJSProvider,
    AppVariablesProvider,
    ComponentRefProvider,
    PartialRefProvider,
    PrefabConfigProvider,
    WM_MODULES_FOR_ROOT,
    REQUIRED_MODULES_FOR_DYNAMIC_COMPONENTS
} from '@wm/runtime/base';


import { routes } from './app.routes';
import { AppJSProviderService } from '../framework/services/app-js-provider.service';
import { AppVariablesProviderService } from '../framework/services/app-variables-provider.service';
import { ComponentRefProviderService } from '../framework/services/component-ref-provider.service';
import { PrefabConfigProviderService } from '../framework/services/prefab-config-provider.service';
import { AppCodeGenModule, xsrfHeaderName } from './app-codegen.module';
import { LazyLoadScriptsResolve } from './lazy-load-scripts.resolve';
import { initPrefabConfig } from './prefabs/prefab-config';

export const modalModule = ModalModule.forRoot();
export const routerModule = RouterModule.forRoot(routes, {useHash: true, scrollPositionRestoration: 'top'});
export const toastrModule = ToastNoAnimationModule.forRoot({maxOpened: 1, autoDismiss: true });
export const bsDatePickerModule: ModuleWithProviders = BsDatepickerModule.forRoot();
export const httpClientXsrfModule = HttpClientXsrfModule.withOptions({
    cookieName: 'wm_xsrf_token',
    headerName: xsrfHeaderName
});

export const ngCircleProgressModule: ModuleWithProviders = NgCircleProgressModule.forRoot({});


export const isPrefabInitialized = initPrefabConfig();

@NgModule({
    declarations: [],
    imports: [
        BrowserModule,
        CommonModule,
        RouterModule,
        HttpClientModule,

        modalModule,

        ngCircleProgressModule,

        routerModule,
        toastrModule,
        httpClientXsrfModule,
        bsDatePickerModule,

        WM_MODULES_FOR_ROOT,
        AppCodeGenModule
    ],
    providers: [
        {provide: AppJSProvider, useClass: AppJSProviderService},
        {provide: AppVariablesProvider, useClass: AppVariablesProviderService},
        {provide: ComponentRefProvider, useClass: ComponentRefProviderService},
        {provide: PartialRefProvider, useClass: ComponentRefProviderService},
        {provide: PrefabConfigProvider, useClass: PrefabConfigProviderService},
        LazyLoadScriptsResolve
    ],
    bootstrap: [AppComponent]
})
export class AppModule {}
